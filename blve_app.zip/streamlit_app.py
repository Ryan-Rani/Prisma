
import streamlit as st
import pandas as pd
from pathlib import Path

st.set_page_config(page_title="BLVE.AGENCY — LinkedIn Growth Dashboard", layout="wide")

st.title("BLVE.AGENCY — LinkedIn Growth Dashboard")

st.markdown(
    """
    **BLVE.AGENCY** is a premium personal brand & thought leadership agency for venture capital GPs.
    We build a LinkedIn‑first presence by training an AI agent on a partner’s writing, books, and talks,
    then pairing voice‑true drafts with on‑brand visuals, scheduling, and analytics.
    Below is a sample dashboard with **made‑up follower counts** for three accounts to illustrate reporting.
    """
)

DATA_DIR = Path(__file__).parent

ACCOUNTS = {
    "Account A": {"monthly": DATA_DIR / "account_A_monthly.csv", "daily": DATA_DIR / "account_A_daily.csv"},
    "Account B": {"monthly": DATA_DIR / "account_B_monthly.csv", "daily": DATA_DIR / "account_B_daily.csv"},
    "Account C": {"monthly": DATA_DIR / "account_C_monthly.csv", "daily": DATA_DIR / "account_C_daily.csv"},
}

st.sidebar.header("Display Options")
show_daily = st.sidebar.checkbox("Show daily (last 30 days) charts", value=True)
show_monthly = st.sidebar.checkbox("Show monthly (last 12 months) charts", value=True)

for name, paths in ACCOUNTS.items():
    st.subheader(name)
    cols = st.columns(2)
    if show_monthly:
        dfm = pd.read_csv(paths["monthly"], parse_dates=["date"])
        with cols[0]:
            st.caption("Monthly followers (last 12 months)")
            st.line_chart(dfm.set_index("date")["followers"])
            st.download_button("Download monthly CSV", dfm.to_csv(index=False).encode("utf-8"),
                               file_name=f"{name.replace(' ', '_').lower()}_monthly.csv",
                               mime="text/csv")
    if show_daily:
        dfd = pd.read_csv(paths["daily"], parse_dates=["date"])
        with cols[1]:
            st.caption("Daily followers (last 30 days)")
            st.line_chart(dfd.set_index("date")["followers"])
            st.download_button("Download daily CSV", dfd.to_csv(index=False).encode("utf-8"),
                               file_name=f"{name.replace(' ', '_').lower()}_daily.csv",
                               mime="text/csv")
    st.markdown("---")

st.markdown("Made-up data for demonstration only.")

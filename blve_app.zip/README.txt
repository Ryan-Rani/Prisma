
BLVE.AGENCY — LinkedIn Growth Dashboard (Sample)

What this is:
- A Streamlit app that explains BLVE at the top, then shows sample follower trends
  for three LinkedIn accounts (A, B, C).
- Each account includes:
    * Monthly data for the last 12 months
    * Daily data for the last 30 days
  (All values are made-up for demonstration.)

How to run locally:
1) Ensure Python 3.9+ is installed.
2) In a terminal, navigate into this folder.
   e.g., cd blve_app
3) Create a virtual environment (optional but recommended):
   python -m venv .venv && source .venv/bin/activate   # macOS/Linux
   .venv\Scripts\activate                             # Windows PowerShell
4) Install dependencies:
   pip install streamlit pandas
5) Run the app:
   streamlit run streamlit_app.py

Files:
- streamlit_app.py
- account_A_monthly.csv, account_A_daily.csv
- account_B_monthly.csv, account_B_daily.csv
- account_C_monthly.csv, account_C_daily.csv

Notes:
- The data is intentionally simple and randomly perturbed to simulate growth.
- Replace CSVs with your real exports when ready; the app will pick them up automatically.
- You can customize colors and themes via Streamlit's config if desired.
